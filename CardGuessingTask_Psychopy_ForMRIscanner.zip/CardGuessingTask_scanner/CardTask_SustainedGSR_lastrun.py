#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.80.04), Tue Aug 12 16:18:24 2014
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Store info about the experiment session
expName = u'CardTask'  # from the Builder filename that created this script
expInfo = {u'participant': u'NSSI143', u'runOrder': u'B', u'mriMode': u'Scan', u'hand': u'right', u'session': u'001', u'taskOrder': u'1'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Setup filename for saving
filename = 'data/%s_%s' %(expInfo['participant'], expName)

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/NSSI/Dropbox/CardGuessing/scanTask/CardTask_SustainedGSR.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
#save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1280, 1024), fullscr=True, screen=0, allowGUI=False, allowStencil=False,
    monitor=u'scannerMonitor', color=[-1,-1,-1], colorSpace=u'rgb',
    blendMode=u'avg', useFBO=True,
    units=u'deg')
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
welcomeText = visual.TextStim(win=win, ori=0, name='welcomeText',
    text='Welcome to the Card Game!\n\n\n',    font='Arial',
    pos=[0, 0], height=1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
polygon = visual.Rect(win=win, name='polygon',
    width=[2, 2][0], height=[2, 2][1],
    ori=0, pos=[-19, 12],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=[1,1,1], fillColorSpace='rgb',
    opacity=1,interpolate=True)

# Initialize components for Routine "Directions"
DirectionsClock = core.Clock()
direction1 = visual.TextStim(win=win, ori=0, name='direction1',
    text='In this game, your job is to guess whether the number on the back of a card is higher or lower than 5. This number is between 1 and 9.\r\n\r\nWhen you see the ?, you should press a button to make your guess. To choose lower, press the button under your pointer finger. To choose higher, press the button under your middle finger.\r\n\r\nIf you are correct, you will win money, but if you are incorrect you will lose money. Be sure to respond for every guess. If you do not respond, you will lose money.',    font='Arial',
    pos=[0, 0], height=1, wrapWidth=25,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
runOrderFile = os.path.join('conditions', 'CardValues%s.xlsx' % expInfo['runOrder'])
logging.exp("Using run order file: %s" % runOrderFile)

# Initialize components for Routine "getReady"
getReadyClock = core.Clock()
startScreen = visual.TextStim(win=win, ori=0, name='startScreen',
    text='Get Ready!',    font='Arial',
    pos=[0, 0], height=1.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)

# Initialize components for Routine "waitForScanner"
waitForScannerClock = core.Clock()
fmriClock = core.Clock()
trigger = 'usb'
#trigger = 'parallel'
if trigger == 'parallel':
    from psychopy.contrib import parallel as winioport
    #from psychopy import parallel
elif trigger == 'usb':
    from psychopy.hardware.emulator import launchScan
    #
    # settings for launchScan:
    MR_settings = { 
        'TR': 2.000, # duration (sec) per volume
        'volumes': 210, # number of whole-brain 3D volumes / frames
        'sync': 'equal', # character to use as the sync timing event; assumed to come at start of a volume
        'skip': 0, # number of volumes lacking a sync pulse at start of scan (for T1 stabilization)
        }

# for GSR sync
import serial
class HvdSerial(serial.Serial):
    DEVICES = {0:'BNC',1:'Parallel'}
    def __init__(self,**args):
        try:
            self._device_present = True
            super(HvdSerial,self).__init__(**args)
            logging.exp('Created device %s' % args['port'])
        except serial.SerialException:
            self._device_present = False
            logging.warn('No Serial Device Found.')

    def writeUSB(self,dest,val):
        if self._device_present:
            self.write(chr(dest))
            self.write(chr(val))
        logging.exp('Serial: Wrote %s (%s) to %s (%s)'%(
            val, "{0:08b}".format(val), dest, self.DEVICES[dest]
        ))

ser = HvdSerial(port='/dev/tty.usbmodem12341',timeout=1)
# Zero Out Parallel & BNC
ser.writeUSB(0,0)
core.wait(.3)
ser.writeUSB(1,0)
core.wait(.3)



# Initialize components for Routine "trial_cue"
trial_cueClock = core.Clock()
# set border color
borderColor='black'

# set win/loss cues
winAmount=None
lossAmount=None
winCueMsg=None
lossCueMsg=None

frame1 = visual.Rect(win=win, name='frame1',
    width=[18, 18][0], height=[18, 18][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor='white', lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
frame2 = visual.Rect(win=win, name='frame2',
    width=[19, 19][0], height=[19, 19][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
circle = visual.Polygon(win=win, name='circle',
    edges = 90, size=[15, 15],
    ori=0, pos=[0, 0],
    lineWidth=2, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
line = visual.Line(win=win, name='line',
    start=(-[15, 0][0]/2.0, 0), end=(+[15, 0][0]/2.0, 0),
    ori=0, pos=[0, 0],
    lineWidth=2, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
StakesWin = visual.TextStim(win=win, ori=0, name='StakesWin',
    text='default text',    font='Arial',
    pos=[0, 3], height=2, wrapWidth=None,
    color=[-1.000,1.000,-1.000], colorSpace='rgb', opacity=1,
    depth=-5.0)
StakesLoss = visual.TextStim(win=win, ori=0, name='StakesLoss',
    text='default text',    font='Arial',
    pos=[0, -3], height=2, wrapWidth=None,
    color=[1.000,-1.000,-1.000], colorSpace='rgb', opacity=1,
    depth=-6.0)
import time
expInfo['expStartTime'] = time.ctime()

BLOCK_DURATION = 10
blockClock = core.Clock()





# Initialize components for Routine "jitter"
jitterClock = core.Clock()
jitteredISI = visual.TextStim(win=win, ori=0, name='jitteredISI',
    text='+',    font='Arial',
    pos=[0, 0], height=1.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
jitterFrame1 = visual.Rect(win=win, name='jitterFrame1',
    width=[18, 18][0], height=[18, 18][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
jitterFrame2 = visual.Rect(win=win, name='jitterFrame2',
    width=[19, 19][0], height=[19, 19][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)


# Initialize components for Routine "trial"
trialClock = core.Clock()
# set border color
borderColor='black'

# set outcome values
outcomeNumber='0'
outcomeText='0'

correct=None

trialFrame = visual.Rect(win=win, name='trialFrame',
    width=[18, 18][0], height=[18, 18][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor='white', lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
trialFrame2 = visual.Rect(win=win, name='trialFrame2',
    width=[19, 19][0], height=[19, 19][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor='black', lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
guess = visual.TextStim(win=win, ori=0, name='guess',
    text='?',    font='Arial',
    pos=[0, 0], height=3, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-3.0)
guessCard = visual.Rect(win=win, name='guessCard',
    width=[12, 15][0], height=[12, 15][1],
    ori=0, pos=[0, 0],
    lineWidth=2, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)

BlocksFeedback=None
Feedback = None


# Initialize components for Routine "jitter2"
jitter2Clock = core.Clock()
jitteredISI_2 = visual.TextStim(win=win, ori=0, name='jitteredISI_2',
    text='+',    font='Arial',
    pos=[0, 0], height=1.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
jitterFrame1_2 = visual.Rect(win=win, name='jitterFrame1_2',
    width=[18, 18][0], height=[18, 18][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
jitterFrame2_2 = visual.Rect(win=win, name='jitterFrame2_2',
    width=[19, 19][0], height=[19, 19][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)


# Initialize components for Routine "feedback"
feedbackClock = core.Clock()
# set reward text color
rewardColor='white'
rewardAmount=None
feedbackName=None
FBType = None
fdback = visual.TextStim(win=win, ori=0, name='fdback',
    text='default text',    font='Arial',
    pos=[0, 2], height=2, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)
reward = visual.TextStim(win=win, ori=0, name='reward',
    text='default text',    font='Arial',
    pos=[0, -1], height=2, wrapWidth=None,
    color=1.0, colorSpace='rgb', opacity=1,
    depth=-2.0)
rewardFrame1 = visual.Rect(win=win, name='rewardFrame1',
    width=[18, 18][0], height=[18, 18][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)
rewardFrame2 = visual.Rect(win=win, name='rewardFrame2',
    width=[19, 19][0], height=[19, 19][1],
    ori=0, pos=[0, 0],
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=None, fillColorSpace='rgb',
    opacity=1,interpolate=True)



# Initialize components for Routine "Break"
BreakClock = core.Clock()
breakJitter = visual.TextStim(win=win, ori=0, name='breakJitter',
    text='+',    font='Arial',
    pos=[0, 0], height=1.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)


# Initialize components for Routine "endRun"
endRunClock = core.Clock()
endRunText = visual.TextStim(win=win, ori=0, name='endRunText',
    text='You finished this round!',    font='Arial',
    pos=[0, 0], height=1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)


# Initialize components for Routine "End"
EndClock = core.Clock()
text_2 = visual.TextStim(win=win, ori=0, name='text_2',
    text='Congratulations! You finished!',    font='Arial',
    pos=[0, 0], height=1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "Welcome"-------
t = 0
WelcomeClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
advanceWelcomeScreen = event.BuilderKeyResponse()  # create an object of type KeyResponse
advanceWelcomeScreen.status = NOT_STARTED
# keep track of which components have finished
WelcomeComponents = []
WelcomeComponents.append(welcomeText)
WelcomeComponents.append(advanceWelcomeScreen)
WelcomeComponents.append(polygon)
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "Welcome"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = WelcomeClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcomeText* updates
    if t >= 0.0 and welcomeText.status == NOT_STARTED:
        # keep track of start time/frame for later
        welcomeText.tStart = t  # underestimates by a little under one frame
        welcomeText.frameNStart = frameN  # exact frame index
        welcomeText.setAutoDraw(True)
    
    # *advanceWelcomeScreen* updates
    if t >= 0.0 and advanceWelcomeScreen.status == NOT_STARTED:
        # keep track of start time/frame for later
        advanceWelcomeScreen.tStart = t  # underestimates by a little under one frame
        advanceWelcomeScreen.frameNStart = frameN  # exact frame index
        advanceWelcomeScreen.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if advanceWelcomeScreen.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # *polygon* updates
    if t >= 0.0 and polygon.status == NOT_STARTED:
        # keep track of start time/frame for later
        polygon.tStart = t  # underestimates by a little under one frame
        polygon.frameNStart = frameN  # exact frame index
        polygon.setAutoDraw(True)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineTimer.reset()  # if we abort early the non-slip timer needs reset
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()
    else:  # this Routine was not non-slip safe so reset non-slip timer
        routineTimer.reset()

#-------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

#------Prepare to start Routine "Directions"-------
t = 0
DirectionsClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_2.status = NOT_STARTED

# keep track of which components have finished
DirectionsComponents = []
DirectionsComponents.append(direction1)
DirectionsComponents.append(key_resp_2)
for thisComponent in DirectionsComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "Directions"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = DirectionsClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *direction1* updates
    if t >= 0.0 and direction1.status == NOT_STARTED:
        # keep track of start time/frame for later
        direction1.tStart = t  # underestimates by a little under one frame
        direction1.frameNStart = frameN  # exact frame index
        direction1.setAutoDraw(True)
    
    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # underestimates by a little under one frame
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineTimer.reset()  # if we abort early the non-slip timer needs reset
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in DirectionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()
    else:  # this Routine was not non-slip safe so reset non-slip timer
        routineTimer.reset()

#-------Ending Routine "Directions"-------
for thisComponent in DirectionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)


# set up handler to look after randomisation of conditions etc
Run = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=u'/Users/NSSI/Dropbox/CardGuessing/scanTask/CardTask_SustainedGSR.psyexp',
    trialList=data.importConditions('conditions/CardRuns.xlsx'),
    seed=None, name='Run')
thisExp.addLoop(Run)  # add the loop to the experiment
thisRun = Run.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisRun.rgb)
if thisRun != None:
    for paramName in thisRun.keys():
        exec(paramName + '= thisRun.' + paramName)

for thisRun in Run:
    currentLoop = Run
    # abbreviate parameter names if possible (e.g. rgb = thisRun.rgb)
    if thisRun != None:
        for paramName in thisRun.keys():
            exec(paramName + '= thisRun.' + paramName)
    
    #------Prepare to start Routine "getReady"-------
    t = 0
    getReadyClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    advanceScreen = event.BuilderKeyResponse()  # create an object of type KeyResponse
    advanceScreen.status = NOT_STARTED
    # keep track of which components have finished
    getReadyComponents = []
    getReadyComponents.append(startScreen)
    getReadyComponents.append(advanceScreen)
    for thisComponent in getReadyComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "getReady"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = getReadyClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *startScreen* updates
        if t >= 0.0 and startScreen.status == NOT_STARTED:
            # keep track of start time/frame for later
            startScreen.tStart = t  # underestimates by a little under one frame
            startScreen.frameNStart = frameN  # exact frame index
            startScreen.setAutoDraw(True)
        
        # *advanceScreen* updates
        if t >= 0.0 and advanceScreen.status == NOT_STARTED:
            # keep track of start time/frame for later
            advanceScreen.tStart = t  # underestimates by a little under one frame
            advanceScreen.frameNStart = frameN  # exact frame index
            advanceScreen.status = STARTED
            # keyboard checking is just starting
            event.clearEvents(eventType='keyboard')
        if advanceScreen.status == STARTED:
            theseKeys = event.getKeys(keyList=['space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                # a response ends the routine
                continueRoutine = False
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineTimer.reset()  # if we abort early the non-slip timer needs reset
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in getReadyComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
        else:  # this Routine was not non-slip safe so reset non-slip timer
            routineTimer.reset()
    
    #-------Ending Routine "getReady"-------
    for thisComponent in getReadyComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    #------Prepare to start Routine "waitForScanner"-------
    t = 0
    waitForScannerClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    if expInfo['mriMode'] != 'Off':
        if trigger == 'usb':
            vol = launchScan(win, MR_settings, 
                  globalClock=fmriClock, 
                  mode=expInfo['mriMode'])
            if ser: # for GSR sync
                ser.writeUSB(0,1)  # Raise BNC
                ser.writeUSB(1,int('11111111',2))  # Raise all pins for Parallel
    
        elif trigger == 'parallel':
            address = 0x378
            #parallel.setPortAddress(0x378)
            wait_msg = "Get Ready!"
            pinStatus = winioport.inp(address)
            waitMsgStim = visual.TextStim(win, color='white', text=wait_msg)
            waitMsgStim.draw()
            win.flip()
            while True:
                if pinStatus != winioport.inp(address):
                   break
                   # start exp when pin values change
            fmriClock.reset()
            logging.exp('parallel trigger: start of scan')
            win.flip()  # blank the screen on first sync pulse received
    
    expInfo['triggerWallTime'] = time.ctime()
    
    
    Run.addData('TaskVersion', runOrderFile)
    # keep track of which components have finished
    waitForScannerComponents = []
    for thisComponent in waitForScannerComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "waitForScanner"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = waitForScannerClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineTimer.reset()  # if we abort early the non-slip timer needs reset
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in waitForScannerComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
        else:  # this Routine was not non-slip safe so reset non-slip timer
            routineTimer.reset()
    
    #-------Ending Routine "waitForScanner"-------
    for thisComponent in waitForScannerComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    routineTimer.reset()
    
    
    # set up handler to look after randomisation of conditions etc
    block = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=u'/Users/NSSI/Dropbox/CardGuessing/scanTask/CardTask_SustainedGSR.psyexp',
        trialList=data.importConditions(runOrderFile),
        seed=None, name='block')
    thisExp.addLoop(block)  # add the loop to the experiment
    thisBlock = block.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisBlock.rgb)
    if thisBlock != None:
        for paramName in thisBlock.keys():
            exec(paramName + '= thisBlock.' + paramName)
    
    for thisBlock in block:
        currentLoop = block
        # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
        if thisBlock != None:
            for paramName in thisBlock.keys():
                exec(paramName + '= thisBlock.' + paramName)
        
        #------Prepare to start Routine "trial_cue"-------
        t = 0
        trial_cueClock.reset()  # clock 
        frameN = -1
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        # Start the clock
        timer = core.Clock()
        
        if Runs == 'Run1':
            valueCondition = Run1Value
            BlocksFeedback= BlocksFeedback1
        if Runs == 'Run2':
            valueCondition = Run2Value
            BlocksFeedback = BlocksFeedback2
        if Runs == 'Run3':
            valueCondition = Run3Value
            BlocksFeedback = BlocksFeedback3
        if Runs == 'Run4':
            valueCondition = Run4Value
            BlocksFeedback = BlocksFeedback4
        
        # set win/loss cue displays
        if valueCondition== 'low':
            winAmount='$0.20'
            lossAmount='$0.10'
        else:
            winAmount='$1.00'
            lossAmount='$0.50'
        
        winCueMsg = "Win %s" %(winAmount)
        lossCueMsg = "Lose %s" %(lossAmount)
        
        # set border width of 2nd border frame
        if valueCondition == 'low':
             borderColor='black'
        else:
             borderColor='white'
        frame2.setLineColor(borderColor)
        
        
        StakesWin.setText(winCueMsg)
        StakesLoss.setText(lossCueMsg)
        blockClock.reset()
        cueTimeAdded = False
        responseTimeAdded = False
        feedbackTimeAdded = False
        # Zero Trigger after 1s (to give analog signal on pins time to rise)
        triggerZeroed= False
        
        
        if valueCondition=='low': # set pins for cue in low block
            pins='00000101'
        else:
            pins='00000110' # set pins for cue in high block
        
        ser.writeUSB(1,int(pins,2))
        # keep track of which components have finished
        trial_cueComponents = []
        trial_cueComponents.append(frame1)
        trial_cueComponents.append(frame2)
        trial_cueComponents.append(circle)
        trial_cueComponents.append(line)
        trial_cueComponents.append(StakesWin)
        trial_cueComponents.append(StakesLoss)
        for thisComponent in trial_cueComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "trial_cue"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = trial_cueClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *frame1* updates
            if t >= 0.0 and frame1.status == NOT_STARTED:
                # keep track of start time/frame for later
                frame1.tStart = t  # underestimates by a little under one frame
                frame1.frameNStart = frameN  # exact frame index
                frame1.setAutoDraw(True)
            elif frame1.status == STARTED and t >= (0.0 + (1-win.monitorFramePeriod*0.75)): #most of one frame period left
                frame1.setAutoDraw(False)
            
            # *frame2* updates
            if t >= 0.0 and frame2.status == NOT_STARTED:
                # keep track of start time/frame for later
                frame2.tStart = t  # underestimates by a little under one frame
                frame2.frameNStart = frameN  # exact frame index
                frame2.setAutoDraw(True)
            elif frame2.status == STARTED and t >= (0.0 + (1-win.monitorFramePeriod*0.75)): #most of one frame period left
                frame2.setAutoDraw(False)
            
            # *circle* updates
            if t >= 0.0 and circle.status == NOT_STARTED:
                # keep track of start time/frame for later
                circle.tStart = t  # underestimates by a little under one frame
                circle.frameNStart = frameN  # exact frame index
                circle.setAutoDraw(True)
            elif circle.status == STARTED and t >= (0.0 + (1.0-win.monitorFramePeriod*0.75)): #most of one frame period left
                circle.setAutoDraw(False)
            
            # *line* updates
            if t >= 0.0 and line.status == NOT_STARTED:
                # keep track of start time/frame for later
                line.tStart = t  # underestimates by a little under one frame
                line.frameNStart = frameN  # exact frame index
                line.setAutoDraw(True)
            elif line.status == STARTED and t >= (0.0 + (1.0-win.monitorFramePeriod*0.75)): #most of one frame period left
                line.setAutoDraw(False)
            
            # *StakesWin* updates
            if t >= 0.0 and StakesWin.status == NOT_STARTED:
                # keep track of start time/frame for later
                StakesWin.tStart = t  # underestimates by a little under one frame
                StakesWin.frameNStart = frameN  # exact frame index
                StakesWin.setAutoDraw(True)
            elif StakesWin.status == STARTED and t >= (0.0 + (1.0-win.monitorFramePeriod*0.75)): #most of one frame period left
                StakesWin.setAutoDraw(False)
            
            # *StakesLoss* updates
            if t >= 0.0 and StakesLoss.status == NOT_STARTED:
                # keep track of start time/frame for later
                StakesLoss.tStart = t  # underestimates by a little under one frame
                StakesLoss.frameNStart = frameN  # exact frame index
                StakesLoss.setAutoDraw(True)
            elif StakesLoss.status == STARTED and t >= (0.0 + (1.0-win.monitorFramePeriod*0.75)): #most of one frame period left
                StakesLoss.setAutoDraw(False)
            
            if not cueTimeAdded:
                currentLoop.addData('cueOnset', fmriClock.getTime())
                cueTimeAdded = True
            
            if not triggerZeroed and t > 1:
                if (valueCondition.startswith("low")):
                    pins = '00000001'
                elif (valueCondition.startswith("high")):
                    pins = '00000010'
            
                ser.writeUSB(0,0) 
                ser.writeUSB(1,int(pins,2)) 
                triggerZeroed = True
            
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineTimer.reset()  # if we abort early the non-slip timer needs reset
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in trial_cueComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "trial_cue"-------
        for thisComponent in trial_cueComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        block.addData('BlockValue', valueCondition)
        
        currentLoop.addData('cueOffset', fmriClock.getTime())
        
        if valueCondition=='low': # set pins for low block
            pins='00000001'
        else:
            pins='00000010' # set pins for high block
        
        ser.writeUSB(1,int(pins,2))
        
        # set up handler to look after randomisation of conditions etc
        trials = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=u'/Users/NSSI/Dropbox/CardGuessing/scanTask/CardTask_SustainedGSR.psyexp',
            trialList=data.importConditions('conditions/CardTask.xlsx'),
            seed=None, name='trials')
        thisExp.addLoop(trials)  # add the loop to the experiment
        thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb=thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial.keys():
                exec(paramName + '= thisTrial.' + paramName)
        
        for thisTrial in trials:
            currentLoop = trials
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial != None:
                for paramName in thisTrial.keys():
                    exec(paramName + '= thisTrial.' + paramName)
            
            #------Prepare to start Routine "jitter"-------
            t = 0
            jitterClock.reset()  # clock 
            frameN = -1
            # update component parameters for each repeat
            # set border color of 2nd border frame
            if valueCondition == 'low':
                 borderColor='black'
            else:
                 borderColor='white'
            jitterFrame2.setLineColor(borderColor)
            
            # keep track of which components have finished
            jitterComponents = []
            jitterComponents.append(jitteredISI)
            jitterComponents.append(jitterFrame1)
            jitterComponents.append(jitterFrame2)
            for thisComponent in jitterComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            #-------Start Routine "jitter"-------
            continueRoutine = True
            while continueRoutine:
                # get current time
                t = jitterClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *jitteredISI* updates
                if t >= 0.0 and jitteredISI.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitteredISI.tStart = t  # underestimates by a little under one frame
                    jitteredISI.frameNStart = frameN  # exact frame index
                    jitteredISI.setAutoDraw(True)
                elif jitteredISI.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitteredISI.setAutoDraw(False)
                
                # *jitterFrame1* updates
                if t >= 0.0 and jitterFrame1.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitterFrame1.tStart = t  # underestimates by a little under one frame
                    jitterFrame1.frameNStart = frameN  # exact frame index
                    jitterFrame1.setAutoDraw(True)
                elif jitterFrame1.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitterFrame1.setAutoDraw(False)
                
                # *jitterFrame2* updates
                if t >= 0.0 and jitterFrame2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitterFrame2.tStart = t  # underestimates by a little under one frame
                    jitterFrame2.frameNStart = frameN  # exact frame index
                    jitterFrame2.setAutoDraw(True)
                elif jitterFrame2.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitterFrame2.setAutoDraw(False)
                
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineTimer.reset()  # if we abort early the non-slip timer needs reset
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in jitterComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
                else:  # this Routine was not non-slip safe so reset non-slip timer
                    routineTimer.reset()
            
            #-------Ending Routine "jitter"-------
            for thisComponent in jitterComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            
            #------Prepare to start Routine "trial"-------
            t = 0
            trialClock.reset()  # clock 
            frameN = -1
            routineTimer.add(1.500000)
            # update component parameters for each repeat
            # set border color of 2nd border frame
            if valueCondition == 'low':
                 borderColor='black'
            else:
                 borderColor='white'
            trialFrame2.setLineColor(borderColor)
            
            # Get start time
            #if Target.status==STARTED:
            #     targetOnset=timer.gettime()
            
            
            guessResp = event.BuilderKeyResponse()  # create an object of type KeyResponse
            guessResp.status = NOT_STARTED
            trials.addData('guessOnset', fmriClock.getTime())
            if BlocksFeedback == 'FBBlock1':
                Feedback = BlockFeedback1
            if BlocksFeedback == 'FBBlock2':
                Feedback = BlockFeedback2
            if BlocksFeedback == 'FBBlock3':
                Feedback = BlockFeedback3
            if valueCondition=='low': # set pins for guess in low block
                pins='00001001'
            else:
                pins='00001010' # set pins for guess in high block
            
            ser.writeUSB(1,int(pins,2))
            # keep track of which components have finished
            trialComponents = []
            trialComponents.append(trialFrame)
            trialComponents.append(trialFrame2)
            trialComponents.append(guess)
            trialComponents.append(guessResp)
            trialComponents.append(guessCard)
            for thisComponent in trialComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            #-------Start Routine "trial"-------
            continueRoutine = True
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = trialClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                
                # *trialFrame* updates
                if t >= 0 and trialFrame.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    trialFrame.tStart = t  # underestimates by a little under one frame
                    trialFrame.frameNStart = frameN  # exact frame index
                    trialFrame.setAutoDraw(True)
                elif trialFrame.status == STARTED and t >= (0 + (1.5-win.monitorFramePeriod*0.75)): #most of one frame period left
                    trialFrame.setAutoDraw(False)
                
                # *trialFrame2* updates
                if t >= 0 and trialFrame2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    trialFrame2.tStart = t  # underestimates by a little under one frame
                    trialFrame2.frameNStart = frameN  # exact frame index
                    trialFrame2.setAutoDraw(True)
                elif trialFrame2.status == STARTED and t >= (0 + (1.5-win.monitorFramePeriod*0.75)): #most of one frame period left
                    trialFrame2.setAutoDraw(False)
                
                # *guess* updates
                if t >= 0 and guess.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    guess.tStart = t  # underestimates by a little under one frame
                    guess.frameNStart = frameN  # exact frame index
                    guess.setAutoDraw(True)
                elif guess.status == STARTED and t >= (0 + (1.5-win.monitorFramePeriod*0.75)): #most of one frame period left
                    guess.setAutoDraw(False)
                
                # *guessResp* updates
                if t >= 0.0 and guessResp.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    guessResp.tStart = t  # underestimates by a little under one frame
                    guessResp.frameNStart = frameN  # exact frame index
                    guessResp.status = STARTED
                    # keyboard checking is just starting
                    guessResp.clock.reset()  # now t=0
                    event.clearEvents(eventType='keyboard')
                elif guessResp.status == STARTED and t >= (0.0 + (1.5-win.monitorFramePeriod*0.75)): #most of one frame period left
                    guessResp.status = STOPPED
                if guessResp.status == STARTED:
                    theseKeys = event.getKeys(keyList=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'])
                    
                    # check for quit:
                    if "escape" in theseKeys:
                        endExpNow = True
                    if len(theseKeys) > 0:  # at least one key was pressed
                        if guessResp.keys == []:  # then this was the first keypress
                            guessResp.keys = theseKeys[0]  # just the first key pressed
                            guessResp.rt = guessResp.clock.getTime()
                
                # *guessCard* updates
                if t >= 0 and guessCard.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    guessCard.tStart = t  # underestimates by a little under one frame
                    guessCard.frameNStart = frameN  # exact frame index
                    guessCard.setAutoDraw(True)
                elif guessCard.status == STARTED and t >= (0 + (1.5-win.monitorFramePeriod*0.75)): #most of one frame period left
                    guessCard.setAutoDraw(False)
                
                
                
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineTimer.reset()  # if we abort early the non-slip timer needs reset
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            #-------Ending Routine "trial"-------
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            # check responses
            if guessResp.keys in ['', [], None]:  # No response was made
               guessResp.keys=None
            # store data for trials (TrialHandler)
            trials.addData('guessResp.keys',guessResp.keys)
            if guessResp.keys != None:  # we had a response
                trials.addData('guessResp.rt', guessResp.rt)
            trials.addData('guessOffset', fmriClock.getTime())
            
            if valueCondition=='low': # set pins for low block
                pins='00000001'
            else:
                pins='00000010' # set pins for high block
            
            ser.writeUSB(1,int(pins,2))
            
            #------Prepare to start Routine "jitter2"-------
            t = 0
            jitter2Clock.reset()  # clock 
            frameN = -1
            # update component parameters for each repeat
            # set border color of 2nd border frame
            if valueCondition == 'low':
                 borderColor='black'
            else:
                 borderColor='white'
            jitterFrame2_2.setLineColor(borderColor)
            
            # keep track of which components have finished
            jitter2Components = []
            jitter2Components.append(jitteredISI_2)
            jitter2Components.append(jitterFrame1_2)
            jitter2Components.append(jitterFrame2_2)
            for thisComponent in jitter2Components:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            #-------Start Routine "jitter2"-------
            continueRoutine = True
            while continueRoutine:
                # get current time
                t = jitter2Clock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *jitteredISI_2* updates
                if t >= 0.0 and jitteredISI_2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitteredISI_2.tStart = t  # underestimates by a little under one frame
                    jitteredISI_2.frameNStart = frameN  # exact frame index
                    jitteredISI_2.setAutoDraw(True)
                elif jitteredISI_2.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitteredISI_2.setAutoDraw(False)
                
                # *jitterFrame1_2* updates
                if t >= 0.0 and jitterFrame1_2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitterFrame1_2.tStart = t  # underestimates by a little under one frame
                    jitterFrame1_2.frameNStart = frameN  # exact frame index
                    jitterFrame1_2.setAutoDraw(True)
                elif jitterFrame1_2.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitterFrame1_2.setAutoDraw(False)
                
                # *jitterFrame2_2* updates
                if t >= 0.0 and jitterFrame2_2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    jitterFrame2_2.tStart = t  # underestimates by a little under one frame
                    jitterFrame2_2.frameNStart = frameN  # exact frame index
                    jitterFrame2_2.setAutoDraw(True)
                elif jitterFrame2_2.status == STARTED and t >= (0.0 + (ISI1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    jitterFrame2_2.setAutoDraw(False)
                
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineTimer.reset()  # if we abort early the non-slip timer needs reset
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in jitter2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
                else:  # this Routine was not non-slip safe so reset non-slip timer
                    routineTimer.reset()
            
            #-------Ending Routine "jitter2"-------
            for thisComponent in jitter2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            
            
            #------Prepare to start Routine "feedback"-------
            t = 0
            feedbackClock.reset()  # clock 
            frameN = -1
            # update component parameters for each repeat
            # set border color of 2nd border frame
            if valueCondition == 'low':
                 borderColor='black'
            else:
                 borderColor='white'
            rewardFrame2.setLineColor(borderColor)
            
            
            # account for missed responses
            
            # calculate feedback and reward
            if guessResp.keys:
              if Feedback == 1:
                feedbackName="Correct"
                rewardColor=[-1.000,1.000,-1.000]
                if valueCondition == "low":
                  rewardAmount="$0.20"
                  FBType = "LowCorr"
                  trials.addData('LowCorrFBOnset', fmriClock.getTime())
                else: # for high block
                  rewardAmount="$1.00"
                  FBType = "HighCorr"
                  trials.addData('HighCorrFBOnset', fmriClock.getTime())
            
              if Feedback == 0:
                feedbackName="Incorrect"
                rewardColor=[1.000,-1.000,-1.000]
                if valueCondition == "low":
                  rewardAmount="-$0.10"
                  FBType = "LowIncorr"
                  trials.addData('LowIncorrFBOnset', fmriClock.getTime())
                else: # for high block
                  rewardAmount="-$0.50"
                  FBType = "HighIncorr"
                  trials.addData('HighIncorrFBOnset', fmriClock.getTime())
            else: # if no response 
                feedbackName = "No Response"
                rewardColor = [1.000,-1.000,-1.000]
                trials.addData('NoRespOnset', fmriClock.getTime())
                if valueCondition == "high":
                  rewardAmount = "- $0.50"
                  FBType = "HighNoResp"
                else:
                  rewardAmount = "- $0.10"
                  FBType = "LowNoResp"
            FeedbackMsg = "%s!" %(feedbackName)
            RewardMsg="%s" %(rewardAmount)
            
            trials.addData('FeedbackType', FBType)
            fdback.setText(FeedbackMsg)
            reward.setColor(rewardColor, colorSpace='rgb')
            reward.setText(RewardMsg)
            feedbackOnset= fmriClock.getTime()
            
            
            trials.addData('feedbackOnset', fmriClock.getTime())
            if valueCondition=='low':
                if feedbackName == "Correct":
                    pins = '00010001' # correct FB in low block
                elif feedbackName == "Incorrect": # if incorrect
                    pins = '00100001' # incorrect FB in low block
                elif feedbackName =="No Response": # No Response in low block
                    pins='01000001'
            
            if valueCondition=='high':
                if feedbackName == "Correct":
                    pins = '00010010' # correct FB in low block
                elif feedbackName == "Incorrect": # if incorrect
                    pins = '00100010' # incorrect FB in low block
                elif feedbackName =="No Response": # No Response in high block
                    pins ='01000010'
            
            ser.writeUSB(1,int(pins,2))
            # keep track of which components have finished
            feedbackComponents = []
            feedbackComponents.append(fdback)
            feedbackComponents.append(reward)
            feedbackComponents.append(rewardFrame1)
            feedbackComponents.append(rewardFrame2)
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            #-------Start Routine "feedback"-------
            continueRoutine = True
            while continueRoutine:
                # get current time
                t = feedbackClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                
                # *fdback* updates
                if t >= 0.0 and fdback.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    fdback.tStart = t  # underestimates by a little under one frame
                    fdback.frameNStart = frameN  # exact frame index
                    fdback.setAutoDraw(True)
                elif fdback.status == STARTED and t >= (0.0 + (1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    fdback.setAutoDraw(False)
                
                # *reward* updates
                if t >= 0 and reward.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    reward.tStart = t  # underestimates by a little under one frame
                    reward.frameNStart = frameN  # exact frame index
                    reward.setAutoDraw(True)
                elif reward.status == STARTED and t >= (0 + (1-win.monitorFramePeriod*0.75)): #most of one frame period left
                    reward.setAutoDraw(False)
                
                # *rewardFrame1* updates
                if t >= 0.0 and rewardFrame1.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    rewardFrame1.tStart = t  # underestimates by a little under one frame
                    rewardFrame1.frameNStart = frameN  # exact frame index
                    rewardFrame1.setAutoDraw(True)
                elif rewardFrame1.status == STARTED and (reward.status==STOPPED):
                    rewardFrame1.setAutoDraw(False)
                
                # *rewardFrame2* updates
                if t >= 0.0 and rewardFrame2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    rewardFrame2.tStart = t  # underestimates by a little under one frame
                    rewardFrame2.frameNStart = frameN  # exact frame index
                    rewardFrame2.setAutoDraw(True)
                elif rewardFrame2.status == STARTED and (reward.status==STOPPED):
                    rewardFrame2.setAutoDraw(False)
                
                
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineTimer.reset()  # if we abort early the non-slip timer needs reset
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # check for quit (the Esc key)
                if endExpNow or event.getKeys(keyList=["escape"]):
                    core.quit()
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
                else:  # this Routine was not non-slip safe so reset non-slip timer
                    routineTimer.reset()
            
            #-------Ending Routine "feedback"-------
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            trials.addData('rewardAmount', rewardAmount)
            trials.addData('feedbackName', feedbackName)
            trials.addData('BlockFeedback', BlocksFeedback)
            trials.addData('Feedback', Feedback)
            
            
            if guessResp.keys:
              if Feedback == 1:
                if valueCondition == "low":
                  trials.addData('LowCorrFBOffset', fmriClock.getTime())
                else: # for high block
                  trials.addData('HighCorrFBOffset', fmriClock.getTime())
              if Feedback == 0:
                if valueCondition == "low":
                  trials.addData('LowIncorrFBOffset', fmriClock.getTime())
                else: # for high block
                  trials.addData('HighIncorrFBOffset', fmriClock.getTime())
            else: # if no response 
                trials.addData('NoRespOffset', fmriClock.getTime())
            trials.addData('feedbackOffset', fmriClock.getTime())
            pins='00000000' # lower pins to mark the end of the block
            ser.writeUSB(1,int(pins,2))
            thisExp.nextEntry()
            
        # completed 1 repeats of 'trials'
        
        
        #------Prepare to start Routine "Break"-------
        t = 0
        BreakClock.reset()  # clock 
        frameN = -1
        routineTimer.add(8.000000)
        # update component parameters for each repeat
        pins = '00000000'
        
        ser.writeUSB(1,int(pins,2))
        # keep track of which components have finished
        BreakComponents = []
        BreakComponents.append(breakJitter)
        for thisComponent in BreakComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "Break"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = BreakClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *breakJitter* updates
            if t >= 0.0 and breakJitter.status == NOT_STARTED:
                # keep track of start time/frame for later
                breakJitter.tStart = t  # underestimates by a little under one frame
                breakJitter.frameNStart = frameN  # exact frame index
                breakJitter.setAutoDraw(True)
            elif breakJitter.status == STARTED and t >= (0.0 + (8.0-win.monitorFramePeriod*0.75)): #most of one frame period left
                breakJitter.setAutoDraw(False)
            
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineTimer.reset()  # if we abort early the non-slip timer needs reset
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in BreakComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "Break"-------
        for thisComponent in BreakComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('blockOffset', fmriClock.getTime())
        thisExp.nextEntry()
        
    # completed 1 repeats of 'block'
    
    
    #------Prepare to start Routine "endRun"-------
    t = 0
    endRunClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    advanceRun = event.BuilderKeyResponse()  # create an object of type KeyResponse
    advanceRun.status = NOT_STARTED
    #runOffsetLogged = False
    Run.addData('runOffset', fmriClock.getTime())
    # keep track of which components have finished
    endRunComponents = []
    endRunComponents.append(endRunText)
    endRunComponents.append(advanceRun)
    for thisComponent in endRunComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "endRun"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = endRunClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *endRunText* updates
        if t >= 0.0 and endRunText.status == NOT_STARTED:
            # keep track of start time/frame for later
            endRunText.tStart = t  # underestimates by a little under one frame
            endRunText.frameNStart = frameN  # exact frame index
            endRunText.setAutoDraw(True)
        
        # *advanceRun* updates
        if t >= 0.0 and advanceRun.status == NOT_STARTED:
            # keep track of start time/frame for later
            advanceRun.tStart = t  # underestimates by a little under one frame
            advanceRun.frameNStart = frameN  # exact frame index
            advanceRun.status = STARTED
            # keyboard checking is just starting
            event.clearEvents(eventType='keyboard')
        if advanceRun.status == STARTED:
            theseKeys = event.getKeys(keyList=['space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                # a response ends the routine
                continueRoutine = False
        
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineTimer.reset()  # if we abort early the non-slip timer needs reset
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in endRunComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
        else:  # this Routine was not non-slip safe so reset non-slip timer
            routineTimer.reset()
    
    #-------Ending Routine "endRun"-------
    for thisComponent in endRunComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    #if not runOffsetLogged and breakFixation.status==FINISHED:
    #    runOffsetLogged=True
    #    Run.addData('runOffset', fmriClock.getTime())
    
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'Run'


#------Prepare to start Routine "End"-------
t = 0
EndClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat
key_resp_5 = event.BuilderKeyResponse()  # create an object of type KeyResponse
key_resp_5.status = NOT_STARTED
# keep track of which components have finished
EndComponents = []
EndComponents.append(text_2)
EndComponents.append(key_resp_5)
for thisComponent in EndComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "End"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_2* updates
    if t >= 0 and text_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_2.tStart = t  # underestimates by a little under one frame
        text_2.frameNStart = frameN  # exact frame index
        text_2.setAutoDraw(True)
    
    # *key_resp_5* updates
    if t >= 0 and key_resp_5.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_5.tStart = t  # underestimates by a little under one frame
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        event.clearEvents(eventType='keyboard')
    if key_resp_5.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineTimer.reset()  # if we abort early the non-slip timer needs reset
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()
    else:  # this Routine was not non-slip safe so reset non-slip timer
        routineTimer.reset()

#-------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# reset GSR pins at the end of the task
ser.writeUSB(0,0)
ser.writeUSB(1,0)
ser.close()
win.close()
core.quit()

















win.close()
core.quit()
